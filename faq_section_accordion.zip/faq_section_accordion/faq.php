        <!-- Faq Section Start -->
        <div id="rs-faq" class="rs-faq pt-100 pb-100 md-pt-70 md-pb-70">
            <div class="container">
                <div class="row y-middle">
                    <div class="col-lg-5 pr-40 md-pr-15 md-mb-50">
                        <div class="sec-title">
                            <h2 class="title pb-30">
                            <?= get_sub_field('faq_heading') ?>
                            </h2>
                            <p class="margin-0"><?= get_sub_field('faq_para') ?></p>
                            <div class="btn-part mt-50">
                                <a class="readon consultant discover" href="about.html"><?= get_sub_field('faq_button') ?></a>
                            </div>
                        </div>
                    </div>


                    
                    <div class="col-lg-7 pl-30 md-pl-15">
                        <div class="faq-content">
                     <?php  if( have_rows('faq_repeater') ): $i=1;
                                echo '<div id="accordion" class="accordion">';
                                while ( have_rows('faq_repeater') ) : the_row();
                                $repeater_heading =get_sub_field('repeater_heading');
                                $repeater_para =get_sub_field('repeater_para');
                        ?>
                                <div class="card">
                                    <div class="card-header" id="heading<?php echo $i;?>">
                                        <a class="card-link" href="#" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $i;?>" aria-expanded="true" aria-controls="collapse-<?php echo $i;?>"> <?php echo $repeater_heading; ?></a>
                                    </div>
                                    <div id="collapse-<?php echo $i;?>" class="collapse " data-bs-parent="#accordion" aria-labelledby="heading-<?php echo $i;?>">
                                        <div class="card-body">
                                        <?php echo $repeater_para; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php $i++; // Increment the increment variable
		
	endwhile; //End the loop 
	
	echo '</div>';

else :

    // no rows found
    echo 'Come back tomorrow';

endif; 
?>
                           
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Faq Section End -->